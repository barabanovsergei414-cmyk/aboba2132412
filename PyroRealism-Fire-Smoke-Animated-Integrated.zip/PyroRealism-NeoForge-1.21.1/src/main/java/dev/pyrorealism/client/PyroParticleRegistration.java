package dev.pyrorealism.client;

import dev.pyrorealism.PyroRealism;
import dev.pyrorealism.client.particle.EmberParticle;
import dev.pyrorealism.client.particle.FlameParticle;
import dev.pyrorealism.client.particle.SmokeParticle;
import dev.pyrorealism.registry.PyroParticles;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

@EventBusSubscriber(modid = PyroRealism.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class PyroParticleRegistration {
    private PyroParticleRegistration() {}

    @SubscribeEvent
    public static void registerParticleProviders(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(PyroParticles.SMOKE.get(), sprites -> new SmokeParticle.Provider(sprites, false));
        event.registerSpriteSet(PyroParticles.DARK_SMOKE.get(), sprites -> new SmokeParticle.Provider(sprites, true));
        event.registerSpriteSet(PyroParticles.FLAME.get(), FlameParticle.Provider::new);
        event.registerSpriteSet(PyroParticles.EMBER.get(), EmberParticle.Provider::new);
    }
}
