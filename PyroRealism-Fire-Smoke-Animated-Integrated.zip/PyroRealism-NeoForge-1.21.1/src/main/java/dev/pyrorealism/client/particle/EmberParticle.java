package dev.pyrorealism.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

public final class EmberParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final double phase;

    public EmberParticle(ClientLevel level, double x, double y, double z,
                         double xSpeed, double ySpeed, double zSpeed, SpriteSet sprites) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        this.sprites = sprites;
        this.phase = this.random.nextDouble() * Math.PI * 2.0;
        this.quadSize = 0.035F + this.random.nextFloat() * 0.035F;
        this.lifetime = 28 + this.random.nextInt(38);
        this.gravity = -0.018F;
        this.friction = 0.985F;
        this.hasPhysics = false;
        this.xd = xSpeed * 1.5;
        this.yd = ySpeed + 0.025 + this.random.nextDouble() * 0.025;
        this.zd = zSpeed * 1.5;
        this.setSpriteFromAge(sprites);
        this.setColor(1.0F, 0.42F + this.random.nextFloat() * 0.25F, 0.08F);
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        double flutter = Math.sin(this.age * 0.23 + phase) * 0.0013;
        this.xd += flutter;
        this.zd += Math.cos(this.age * 0.19 + phase) * 0.0013;
        this.yd = Math.max(-0.012, this.yd - 0.00055);
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.985;
        this.yd *= 0.985;
        this.zd *= 0.985;
        float fade = Math.min(1.0F, (this.lifetime - this.age) / 9.0F);
        this.alpha = Math.max(0.0F, fade);
        this.setSpriteFromAge(this.sprites);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public int getLightColor(float partialTick) {
        return 0x00F000F0;
    }

    public static final class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Provider(SpriteSet sprites) { this.sprites = sprites; }

        @Override
        public EmberParticle createParticle(SimpleParticleType type, ClientLevel level,
                                            double x, double y, double z,
                                            double xSpeed, double ySpeed, double zSpeed) {
            return new EmberParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, sprites);
        }
    }
}
