package dev.pyrorealism.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

public final class FlameParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final float initialSize;
    private final double phase;

    public FlameParticle(ClientLevel level, double x, double y, double z,
                         double xSpeed, double ySpeed, double zSpeed, SpriteSet sprites) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        this.sprites = sprites;
        this.phase = this.random.nextDouble() * Math.PI * 2.0;
        this.initialSize = 0.22F + this.random.nextFloat() * 0.18F;
        this.quadSize = initialSize;
        this.lifetime = 18 + this.random.nextInt(14);
        this.gravity = -0.015F;
        this.friction = 0.91F;
        this.hasPhysics = false;
        this.xd = xSpeed;
        this.yd = ySpeed + 0.025;
        this.zd = zSpeed;
        this.setSpriteFromAge(sprites);
        this.setColor(1.0F, 0.72F, 0.36F);
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        float p = this.age / (float) this.lifetime;
        double flicker = Math.sin(this.age * 0.8 + phase);
        this.xd += flicker * 0.0028;
        this.zd += Math.cos(this.age * 0.67 + phase) * 0.0028;
        this.yd = Math.min(this.yd + 0.00075, 0.055);
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.92;
        this.yd *= 0.985;
        this.zd *= 0.92;

        this.quadSize = initialSize * (1.0F - p * 0.58F) * (0.90F + (float) flicker * 0.09F);
        this.alpha = Math.max(0.0F, 1.0F - p * 1.08F);
        float heat = 1.0F - p;
        this.setColor(1.0F, 0.36F + heat * 0.52F, 0.08F + heat * 0.36F);
        this.setSpriteFromAge(this.sprites);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public int getLightColor(float partialTick) {
        return 0x00F000F0;
    }

    public static final class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Provider(SpriteSet sprites) { this.sprites = sprites; }

        @Override
        public FlameParticle createParticle(SimpleParticleType type, ClientLevel level,
                                            double x, double y, double z,
                                            double xSpeed, double ySpeed, double zSpeed) {
            return new FlameParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, sprites);
        }
    }
}
