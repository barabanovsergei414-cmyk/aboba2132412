@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
if errorlevel 1 (
  echo.
  echo Build failed. Read the error message above.
) else (
  echo.
  echo JAR was copied to the dist folder.
)
pause
