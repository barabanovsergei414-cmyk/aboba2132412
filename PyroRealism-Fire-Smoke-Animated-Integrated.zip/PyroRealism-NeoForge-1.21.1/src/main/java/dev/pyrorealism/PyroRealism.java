package dev.pyrorealism;

import dev.pyrorealism.registry.PyroParticles;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(PyroRealism.MOD_ID)
public final class PyroRealism {
    public static final String MOD_ID = "pyrorealism";

    public PyroRealism(IEventBus modBus) {
        PyroParticles.PARTICLE_TYPES.register(modBus);
    }
}
