﻿#requires -Version 5.1
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$gradleVersion = '8.12.1'
$toolDir = Join-Path $root ".tools\gradle-$gradleVersion"
$gradleBat = Join-Path $toolDir 'bin\gradle.bat'

# Check Java 21 using an in-memory process capture (no temporary files).
# This avoids PowerShell 5.1 stderr handling and TEMP-path cleanup issues.
$javaCommand = Get-Command 'java.exe' -ErrorAction SilentlyContinue
if (-not $javaCommand) {
    throw 'Java was not found in PATH. Install JDK 21 and add its bin folder to PATH.'
}

$javaStartInfo = New-Object System.Diagnostics.ProcessStartInfo
$javaStartInfo.FileName = $javaCommand.Source
$javaStartInfo.Arguments = '-version'
$javaStartInfo.RedirectStandardOutput = $true
$javaStartInfo.RedirectStandardError = $true
$javaStartInfo.UseShellExecute = $false
$javaStartInfo.CreateNoWindow = $true

$javaProcess = New-Object System.Diagnostics.Process
$javaProcess.StartInfo = $javaStartInfo
[void]$javaProcess.Start()
$javaStdoutText = $javaProcess.StandardOutput.ReadToEnd()
$javaStderrText = $javaProcess.StandardError.ReadToEnd()
$javaProcess.WaitForExit()
$javaInfo = $javaStdoutText + $javaStderrText
$javaExitCode = $javaProcess.ExitCode
$javaProcess.Dispose()

if ($javaExitCode -ne 0 -or $javaInfo -notmatch 'version\s+"?21(?:[.\-" ]|$)') {
    throw "JDK 21 is required. Detected Java information: $javaInfo"
}
Write-Host "Java 21 found: $($javaCommand.Source)" -ForegroundColor Green

# Keep all build temporary files inside the project, not a possibly invalid TEMP path.
$tempRoot = Join-Path $root '.tools\tmp'
New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
$tempTag = [Guid]::NewGuid().ToString('N')

if (-not (Test-Path $gradleBat)) {
    $toolsParent = Split-Path -Parent $toolDir
    New-Item -ItemType Directory -Force -Path $toolsParent | Out-Null

    $zipPath = Join-Path $tempRoot "gradle-$gradleVersion-bin-$tempTag.zip"
    $extractRoot = Join-Path $tempRoot "pyrorealism-gradle-$gradleVersion-$tempTag"
    $url = "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip"

    try {
        Write-Host "Downloading Gradle $gradleVersion..."
        Invoke-WebRequest -Uri $url -OutFile $zipPath -UseBasicParsing
        if (Test-Path $extractRoot) {
            Remove-Item -LiteralPath $extractRoot -Recurse -Force
        }
        Expand-Archive -LiteralPath $zipPath -DestinationPath $extractRoot -Force

        $stagedGradle = Join-Path $extractRoot "gradle-$gradleVersion"
        if (-not (Test-Path (Join-Path $stagedGradle 'bin\gradle.bat'))) {
            throw 'The downloaded Gradle archive is incomplete or has an unexpected layout.'
        }
        if (Test-Path $toolDir) {
            Remove-Item -LiteralPath $toolDir -Recurse -Force
        }
        Move-Item -LiteralPath $stagedGradle -Destination $toolDir
    }
    finally {
        if (Test-Path -LiteralPath $extractRoot) {
            try { Remove-Item -LiteralPath $extractRoot -Recurse -Force -ErrorAction Stop } catch { Write-Warning 'Could not remove temporary Gradle extraction folder; continuing.' }
        }
        if (Test-Path -LiteralPath $zipPath) {
            try { Remove-Item -LiteralPath $zipPath -Force -ErrorAction Stop } catch { Write-Warning 'Could not remove temporary Gradle ZIP; continuing.' }
        }
    }
}

Push-Location $root
try {
    Write-Host 'Running Gradle clean build...'
    & $gradleBat --no-daemon clean build
    if ($LASTEXITCODE -ne 0) {
        throw "Gradle build failed with exit code $LASTEXITCODE. See the Gradle output above."
    }

    $libsDir = Join-Path $root 'build\libs'
    $jar = Get-ChildItem -LiteralPath $libsDir -Filter '*.jar' -File |
        Where-Object { $_.Name -notlike '*-sources.jar' -and $_.Name -notlike '*-javadoc.jar' } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1

    if (-not $jar) {
        throw 'Gradle finished but no mod JAR was found in build\libs.'
    }

    $dist = Join-Path $root 'dist'
    New-Item -ItemType Directory -Force -Path $dist | Out-Null
    $targetJar = Join-Path $dist 'pyrorealism-0.1.0.jar'
    Copy-Item -LiteralPath $jar.FullName -Destination $targetJar -Force
    Write-Host "Build successful. JAR copied to: $targetJar" -ForegroundColor Green
}
finally {
    Pop-Location
}
